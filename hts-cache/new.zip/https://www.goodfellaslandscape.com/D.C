
  <!DOCTYPE html>
<!--
    

    

  
  
      
-->
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <title>400 Error: Bad Request</title>

    
    <script async src="https://static.parastorage.com/polyfill/v2/polyfill.min.js?features=default,es6,es7,es2017&flags=gated&unknown=polyfill&rum=0"></script>
    <script src="https://static.parastorage.com/unpkg-semver/fedops-logger@5/fedops-logger.bundle.min.js"></script>
    <script>fedopsLogger.reportAppLoadStarted("classic-error-pages-statics");</script>
    <script src="https://static.parastorage.com/unpkg-semver/header-footer-provider/app.bundle.min.js"></script>
    <script crossorigin src="https://static.parastorage.com/unpkg/react@18.2.0/umd/react.production.min.js"></script>
    <script crossorigin src="https://static.parastorage.com/unpkg/react-dom@18.2.0/umd/react-dom.production.min.js"></script>

    <link rel="stylesheet" href="//static.parastorage.com/services/classic-error-pages-statics/1.98.0/app.min.css">

    <link rel="preload" as="font" href="https://static.parastorage.com/unpkg/@wix/wix-fonts@1.14.0/media/WixMadeforTextVF_W_Wght.8022447a.woff2" crossorigin>
    <link rel="preload" as="font" href="https://static.parastorage.com/unpkg/@wix/wix-fonts@1.14.0/media/WixMadeforDisplayVF_W_Wght.ab35e4df.woff2" crossorigin>
    <link rel="stylesheet" href="https://static.parastorage.com/unpkg/@wix/wix-fonts@1.14.0/madefor.min.css">
    <link rel="stylesheet" href="https://static.parastorage.com/unpkg/@wix/wix-fonts@1.14.0/madeforDisplay.min.css">

</head>
<body>
<div id="root"></div>
<script>
    window.__LOCALE__ = 'en';
    window.__ERROR_DATA__ = {
        staticsUrl: '//static.parastorage.com/services/classic-error-pages-statics/1.98.0/',
        baseDomain: 'wix.com',
        errorCode: '400-NotBranded',
        exceptionName: '',
        serverErrorCode: '-100',
        data: {},
        brand: 'wix',
        requestId: '1791337494.3702784787411452'
    };
</script>
<script src="//static.parastorage.com/services/classic-error-pages-statics/1.98.0/app.bundle.min.js"></script>
</body>
</html>
